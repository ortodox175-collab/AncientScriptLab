# AncientScriptLab Roadmap

Version: 1.0

Status: Approved

---

# Mission

AncientScriptLab is a scientific operating system for objective analysis of unknown writing systems.

The project transforms visual symbols into reproducible mathematical feature vectors suitable for statistical comparison.

---

# Golden Rule

Every iteration must finish with a new user capability.

Never with infrastructure only.

---

# Architectural Rule

Finished architecture is frozen.

Changes are allowed only if ALL conditions are true:

1. objectively simplify the system;
2. reduce complexity;
3. preserve compatibility;
4. improve scientific capability.

Otherwise changes are prohibited.

---

# Development Rule

Infrastructure is written only once.

After completion it becomes frozen.

Development continues by adding scientific functionality.

---

# Milestone M1

Scientific Registry

Status

✓ Completed

Frozen

YES

---

# Milestone M2

Execution Core

Status

✓ Completed

Includes

- FeatureContext
- RuntimeRegistry
- ExecutionEngine
- Algorithm

Frozen

YES

---

# Milestone M3

Image Pipeline

Status

✓ Completed

Includes

- ImageLoader
- PNG Support
- Scientific execution

Frozen

YES

---

# Milestone M4

Reference Dataset

Status

✓ Completed

Includes

- Reference geometric corpus
- Regression images
- Scientific validation

Frozen

YES

---

# Milestone M5

Primitive Geometry

Goal

Geometric feature vector.

Includes

- G-001 Width
- G-002 Height
- G-003 Bounding Box Area
- G-004 Foreground Area
- G-005 Perimeter
- G-006 Aspect Ratio
- G-007 Extent
- G-008 Centroid X
- G-009 Centroid Y
- G-010 Compactness

Exit Criterion

A single image can be transformed into a geometric feature vector.

---

# Milestone M6

Derived Geometry

Goal

Higher-order geometric descriptors.

Includes

- Circularity
- Solidity
- Convex Hull
- Hu Moments
- Eccentricity
- Orientation

Exit Criterion

Stable geometric description independent of scale.

---

# Milestone M7

Topology

Goal

Graph representation of symbols.

Includes

- Skeleton
- Junctions
- Endpoints
- Loops
- Connectivity Graph

Exit Criterion

Every symbol has a topological representation.

---

# Milestone M8

Statistical Layer

Goal

Corpus statistics.

Includes

- Feature distributions
- PCA
- Correlation
- Distance metrics
- Normalization

Exit Criterion

Automatic statistical report.

---

# Milestone M9

Corpus Engine

Goal

Automatic processing of symbol collections.

Exit Criterion

Entire corpus processed automatically.

---

# Milestone M10

Similarity Engine

Goal

Mathematical comparison of writing systems.

Exit Criterion

Automatic similarity report.

---

# Milestone M11

Discovery Engine

Goal

Pattern discovery.

Includes

- Clustering
- Nearest Neighbour Search
- Unknown Symbol Discovery

Exit Criterion

Automatic hypothesis generation.

---

# Milestone M12

Research Workstation

Goal

Complete scientific environment.

Includes

- Visualization
- Reports
- Export
- Interactive exploration

Exit Criterion

Research-ready platform.

---

# Project Rule

No completed milestone may be modified.

Only bug fixes are allowed.

Architectural redesign is forbidden unless explicitly approved.

---

# Roadmap Rule

Any new idea must first be checked against this ROADMAP.

If it does not move the current milestone forward or requires changing frozen architecture, it is moved to BACKLOG and is not implemented.

---

# Current Milestone

M5 — Primitive Geometry

