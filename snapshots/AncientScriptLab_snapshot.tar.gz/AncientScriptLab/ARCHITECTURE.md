# AncientScriptLab 2.0 (Research Edition)

## Mission

AncientScriptLab is a universal scientific platform for reproducible mathematical analysis of ancient and undeciphered writing systems.

The platform does not attempt to translate unknown scripts.

Its purpose is to objectively measure, compare and analyze sign systems using reproducible computational methods.

---

# Core Principles

## 1. Objectivity

The system never assigns meanings to signs.

Only measurable properties are stored and analyzed.

Examples:

- frequency
- position
- neighborhood
- entropy
- graph topology
- geometric properties
- statistical relations

Semantic interpretation belongs only to external research hypotheses.

---

## 2. Separation of Facts and Hypotheses

Facts and hypotheses must never be mixed.

Facts:

- sign IDs
- corpus structure
- geometry
- statistics

Hypotheses:

- human
- fish
- deity
- grammar
- language

Hypotheses are optional layers built on top of objective data.

---

## 3. Reproducibility

Every experiment must be reproducible.

For every dataset the platform stores:

- source
- version
- checksum
- parser
- metadata

---

## 4. Modularity

Every subsystem must work independently.

Core modules:

- Record
- Corpus
- Sign
- Library
- Dataset

Analysis modules:

- Frequency
- Graph
- Entropy
- Embeddings
- Clustering

Vision modules:

- Geometry
- Skeleton
- Contours
- Shape descriptors

---

## 5. Universal Internal Representation

External formats may differ.

Internally every writing system becomes:

TextRecord

↓

SignDataset

↓

Pipeline

No analysis module should depend on external corpus format.

---

## 6. Geometry before Interpretation

Images are converted into measurable geometric features.

No semantic labels are created automatically.

---

## 7. Hierarchical Sign Representation (HSR)

Each sign consists of several independent layers.

Level 0

Identity

↓

Level 1

Geometry

↓

Level 2

Statistical behaviour

↓

Level 3

Relations

↓

Level 4

Research hypotheses

The first four levels remain objective.

---

## 8. Pipeline Architecture

Research pipeline:

Dataset

↓

Parser

↓

Normalizer

↓

Feature Engine

↓

Graph Engine

↓

Embedding Engine

↓

Cluster Engine

↓

Visualization

↓

Research Report

Each stage receives standardized input and produces standardized output.

---

## 9. Scientific Sources

The platform uses only published scientific corpora.

No manually invented corpora are used in research.

---

## 10. Extensibility

Adding a new writing system must require only:

- dataset adapter
- parser

The rest of the platform remains unchanged.

---

# Development Rule

Correctness is always more important than speed.

No feature is added until it is tested and compatible with the existing architecture.

