"""
AncientScriptLab

Input / Output Package
"""
